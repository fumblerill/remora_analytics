from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from routers import upload
from settings import TEMPLATES_DIR, STATIC_DIR

def create_app() -> FastAPI:
    """
    Создаёт и настраивает экземпляр FastAPI-приложения.
    """
    app = FastAPI(title="Remora.Analytics")

    # Подключение статических файлов (CSS, JS)
    app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")

    # Настройка шаблонов Jinja2
    templates = Jinja2Templates(directory=TEMPLATES_DIR)
    app.templates = templates

    # Подключение маршрутов
    app.include_router(upload.router)

    return app


app = create_app()

# Точка входа при запуске из командной строки
if __name__ == "__main__":
    import uvicorn
    from settings import HOST, PORT, RELOAD

    uvicorn.run("main:app", host=HOST, port=PORT, reload=RELOAD)