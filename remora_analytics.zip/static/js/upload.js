function initServerSideTableWithFilters(id, url) {
    const table = $(`#${id}`);
  
    // Получаем названия колонок для фильтров (после первого запроса)
    $.getJSON(url, { start: 0, length: 1 }, function (sample) {
      const columns = sample.columns;
  
      // Вставляем строку для фильтров
      const thead = table.find("thead");
      if (thead.find("tr.filter-row").length === 0) {
        const filterRow = $("<tr>").addClass("filter-row");
        columns.forEach(() => {
          filterRow.append('<th><select class="form-select form-select-sm"><option value="">Все</option></select></th>');
        });
        thead.append(filterRow);
      }
  
      // DataTable init
      const dt = table.DataTable({
        processing: true,
        serverSide: true,
        paging: false,        // Только 1 страница, без пагинации
        searching: false,     // Без общего поиска
        lengthChange: false,  // Без выбора длины страницы
        scrollX: false,       // Можно убрать горизонтальный скролл
        ajax: {
          url: url,
          type: "GET",
          data: function(d) {
            // Добавляем параметры фильтрации
            table.find("thead tr.filter-row th select").each(function(idx) {
              d['columns[' + idx + '][search][value]'] = $(this).val();
            });
          }
        },
        columns: columns,
        language: {
          url: "//cdn.datatables.net/plug-ins/1.13.6/i18n/ru.json",
        }
      });
  
      // Фильтры — при смене значения перерисовываем таблицу
      table.find("thead tr.filter-row th select").on("change", function() {
        dt.ajax.reload();
      });
  
      // Заполняем селекты уникальными значениями
      $.getJSON(url, { start: 0, length: 1000 }, function (sample2) {
        sample2.columns.forEach(function(col, i) {
          const values = new Set();
          sample2.data.forEach(row => {
            if (row[col.data] && row[col.data].length < 50) values.add(row[col.data]);
          });
          const select = table.find("thead tr.filter-row th").eq(i).find("select");
          Array.from(values).sort().forEach(val => {
            select.append($("<option>").val(val).text(val));
          });
        });
      });
    });
  }  

// // Фильтры через <select> — реальные уникальные значения с сервера
// function initFilters(dt, tableId) {
//     dt.columns().every(function (i) {
//         const column = this;
//         const th = $(column.header());
//         th.empty(); // очищаем заголовок
//         const colTitle = column.dataSrc();
//         const label = $('<div>').text(colTitle).css('font-weight', 'bold');
//         const select = $('<select class="form-select form-select-sm mt-1"><option value="">Все</option></select>');
//         // Получить уникальные значения (для serverSide надо отдельный эндпоинт, иначе — column.data().unique())
//         column.data().unique().sort().each(function (d) {
//             if (d && String(d).length < 50) select.append(`<option value="${d}">${d}</option>`);
//         });
//         select.on('change', function () {
//             column.search(this.value ? `^${this.value}$` : '', true, false).draw();
//         });
//         th.append(label).append(select);
//     });
// }

document.addEventListener("DOMContentLoaded", () => {
    const wrapper = document.getElementById("content-wrapper");
    const preloader = document.getElementById("preloader");

    if (wrapper) {
        wrapper.style.display = "block";
        setTimeout(() => {
            wrapper.style.opacity = "1";
            if (preloader) preloader.remove();

            // Пример для всех таблиц
            initServerSideTableWithFilters("statisticsTable", "/table/statistics");
            initServerSideTableWithFilters("docPerfTable", "/table/doc_perf_500");
            initServerSideTableWithFilters("typesTable", "/table/types");
            initServerSideTableWithFilters("certErrorsTable", "/table/cert_errors");
            initServerSideTableWithFilters("rawTable", "/table/raw");
        }, 100);
    }
});