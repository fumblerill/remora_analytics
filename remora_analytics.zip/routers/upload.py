from fastapi import APIRouter, Request, UploadFile, File, Query
from fastapi.responses import HTMLResponse, JSONResponse
import pandas as pd

from services.xlsx_handler import generate_tables

router = APIRouter()

# Кэш для хранения датафреймов
cached_tables: dict[str, pd.DataFrame] = {}


@router.get("/", response_class=HTMLResponse)
async def index(request: Request):
    return request.app.templates.TemplateResponse("upload.html", {"request": request})


@router.post("/upload", response_class=HTMLResponse)
async def upload(request: Request, file: UploadFile = File(...)):
    if not file.filename.endswith(".xlsx"):
        return request.app.templates.TemplateResponse(
            "upload.html",
            {"request": request, "error": "❗ Поддерживаются только .xlsx файлы"},
        )

    contents = await file.read()
    tables_data = generate_tables(contents)

    # Кэшируем датафреймы по ключам
    cached_tables["statistics"] = tables_data["dfs"]["statistics"]
    cached_tables["doc_perf_500"] = tables_data["dfs"]["doc_perf_500"]
    cached_tables["types"] = tables_data["dfs"]["types"]
    cached_tables["cert_errors"] = tables_data["dfs"]["cert_errors"]
    cached_tables["raw"] = tables_data["dfs"]["raw"]
    cached_tables["reference"] = tables_data["dfs"]["reference"]

    return request.app.templates.TemplateResponse(
        "upload.html",
        {
            "request": request,
            "filename": file.filename,
            "pie_labels": tables_data["pie_labels"],
            "pie_values": tables_data["pie_values"],
            "bar_labels": tables_data["bar_labels"],
            "bar_values": tables_data["bar_values"],
            "summary": tables_data["summary"],
            "min_date": tables_data["min_date"],
            "max_date": tables_data["max_date"],
        },
    )


@router.get("/table/{name}", response_class=JSONResponse)
async def get_table(
    name: str,
    start: int = Query(0),
    length: int = Query(50),
    draw: int = Query(1),
    search: str = Query("", alias="search[value]"),
    columns: list[str] = Query(None)
):
    # ДЛЯ ДЕБАГА — выводим всё что пришло
    import sys
    print("GET /table/{name} PARAMS:")
    print("start:", start, "length:", length, "draw:", draw)
    print("search:", search)
    print("columns:", columns, file=sys.stderr)

    df = cached_tables.get(name)
    if df is None:
        return JSONResponse({"error": "Таблица не найдена"}, status_code=404)

    df_clean = df.copy()

    # Преобразование datetime-колонок в строки
    for col in df_clean.select_dtypes(include=["datetime", "datetimetz"]):
        df_clean[col] = df_clean[col].dt.strftime("%Y-%m-%d %H:%M:%S")
    df_clean = df_clean.fillna("").infer_objects(copy=False)

    # (Пока без фильтрации — просто для дебага)
    page = df_clean.iloc[start:start + length]

    return {
        "draw": draw,
        "recordsTotal": len(df_clean),
        "recordsFiltered": len(df_clean),
        "data": page.to_dict(orient="records"),
        "columns": [{"title": col, "data": col} for col in df_clean.columns],
    }


@router.get("/unique/{table}/{col}", response_class=JSONResponse)
async def unique_column(table: str, col: str):
    df = cached_tables.get(table)
    if df is None or col not in df.columns:
        return JSONResponse([], status_code=404)
    uniques = df[col].dropna().astype(str).unique().tolist()
    uniques = [u for u in uniques if len(u) <= 50]
    return uniques