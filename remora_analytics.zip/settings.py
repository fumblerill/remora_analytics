from pathlib import Path


# Корневая директория проекта
BASE_DIR = Path(__file__).resolve().parent

# Пути к статическим файлам и шаблонам
TEMPLATES_DIR = BASE_DIR / "templates"
STATIC_DIR = BASE_DIR / "static"

# Путь к справочнику ошибок
ERROR_REF_PATH = BASE_DIR / "error_reference.xlsx"

# Настройки сервера
HOST = "127.0.0.1"
PORT = 8000
DEBUG = True
RELOAD = True